#### 1. To import the CSV files into MySQL tables ###

&nbsp;&nbsp;&nbsp;[How to import CSV files into MySQL tables in 4 different ways](https://blog.skyvia.com/how-to-import-csv-file-into-mysql-table-in-4-different-ways)

- - - -

#### 2. To save MySQL query output to a file ####

&nbsp;&nbsp;&nbsp;[How to save the results from a MySQL query output to a CSV of text file](https://www.databasestar.com/mysql-output-file/)
