## The simplest way to explore the data is to see it! ##

#### 1. The tables of the database ####

&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216136408-887b4702-013e-4088-8f81-169ec8a1e640.png" width=30%>

- - - -

#### 2. The columns and top 10 records of each table ####

  - game_sales table
	
	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216138014-b1e20bed-f5a4-4bb4-b7ca-d7c7a005f889.png" width=50%>
	
	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216138642-10c0eebb-9025-40a0-8b5a-afda5de429fe.png" width=80%>

  - reviews table
	
	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216138898-caace644-ba89-490b-a577-ecec8116e528.png" width=50%>

	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216139002-8e4be29a-2f4d-4ebd-ac11-352412aab7fd.png" width=50%>

  - top_critic_years table

	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216139480-193b4782-e752-45c2-b528-7b48b28d680f.png" width=50%>
	
	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216139661-2313ff8f-ebdc-49be-8c77-f6e50e7e8799.png" width=50%>

  - top_critic_years_more_than_four_games table
	
	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216139988-118df025-b804-42be-a604-7d99156be632.png" width=50%>

	
	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216139798-9683ad62-9150-413f-9685-1a3f9d6cd17e.png" width=50%>
	
  - top_user_years_more_than_four_games table

	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216140330-237ba748-bcdf-4b93-8606-af8be3bd0d52.png" width=50%>

	
	&ensp;&thinsp;&ensp;&thinsp;&ensp;&thinsp;<img src="https://user-images.githubusercontent.com/70551007/216140243-77ff78e0-28af-4aaa-a012-babbe59258ed.png" width=50%>
